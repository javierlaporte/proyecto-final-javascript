Toastify({
    text: "Escucha la playlist de Frecuencias en Spotify!!",
    duration: 100000,
    destination:"https://open.spotify.com/playlist/3ewi9aAfCFSideuda1u0ij", 
    className: "info",
    style: {
      background: "linear-gradient(to right, #00b09b, #96c93d)",
    }
  }).showToast();