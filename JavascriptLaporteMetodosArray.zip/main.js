
class Producto {
    constructor (nombre , precioCompra, cantidad){
    this.nombre = nombre.toUpperCase ();
    this.precioCompra = precioCompra;
    this.cantidad = cantidad;

}
calcularcosto = () => this.cantidad * this.precioCompra;
}

//agregar un elemento//
function agregarProductos () {

let numeroProductos = parseInt(
    prompt ("cuantos productos va a ingresar")
);
let  productos = [];
for (let index = 0; index < numeroProductos; index++ ){
    let nombre = prompt("ingrese nombre");
    let precioCompra = prompt ("ingrese el precio de compra");
    let cantidad = prompt ("ingrese la cantidad");
    let productoNuevo= new Producto (nombre,precioCompra,cantidad);
    productos.push (productoNuevo);
}
return productos;
}

function mostrarProductos (productos) {
for (const producto of productos){
    console.log(producto);
    console.log (producto.nombre);
}
}

function calcularcosto (productos){
let suma = 0;
for (const producto of productos ) {
    suma  += producto.calcularcosto ();
}
return suma;
}

function main  () {
let productos = agregarProductos();
mostrarProductos(productos);

let costoTotal = calcularcosto (productos);
alert ("el costo total es " + costoTotal);
}

main ();