
/*class Producto {
    constructor (nombre , precioCompra, cantidad){
    this.nombre = nombre.toUpperCase ();
    this.precioCompra = precioCompra;
    this.cantidad = cantidad;

}
calcularcosto = () => this.cantidad * this.precioCompra;
}

//agregar un elemento//
function agregarProductos () {

let numeroProductos = parseInt(
    prompt ("cuantos productos va a ingresar")
);
let  productos = [];
for (let index = 0; index < numeroProductos; index++ ){
    let nombre = prompt("ingrese nombre");
    let precioCompra = prompt ("ingrese el precio de compra");
    let cantidad = prompt ("ingrese la cantidad");
    let productoNuevo= new Producto (nombre,precioCompra,cantidad);
    productos.push (productoNuevo);
}
return productos;
}

function mostrarProductos (productos) {
for (const producto of productos){
    console.log(producto);
    console.log (producto.nombre);
}
}

function calcularcosto (productos){
let suma = 0;
for (const producto of productos ) {
    suma  += producto.calcularcosto ();
}
return suma;
}

function main  () {
let productos = agregarProductos();
mostrarProductos(productos);

let costoTotal = calcularcosto (productos);
alert ("el costo total es " + costoTotal);
}

main ();
*/




//DESAFIO EVENTOS//

class Canciones {
   constructor (id,nombreartista,cancion,precio,img){
    this.id = id;
    this.nombreartista = nombreartista;
    this.cancion= cancion;
    this.precio= precio;
    this.img= img;
    }
}
//array paso parametros//
const tracks = [

    trackuno= new Canciones (1,"Javier Laporte","Deep Fall",1.29,"img/baltimo.jpg"),
    trackdos= new Canciones (2,"Juan Deminicis","Lighting",1.29, "img/salazar.jpg"),
    tracktres= new Canciones (3,"Alex Orion","Particles",1.29, "img/sunprogress.jpg"),

 ]

//cards recorriendo el array con los objetos del dom //
const carrito = [];
function displayCards () {

    let cardsCanciones = document.getElementById ('cards')
    tracks.forEach((productosCanciones) => {
        cardsCanciones.innerHTML += `
        <div id="cards">
            <div id="imgbox">
                <img src="${productosCanciones.img}" alt= "producto" id="mouse">
            </div>
        
             <div id="contenedorbox">
             <h3>Canciones ${productosCanciones.nombreartista}</h3>
             <h2 class="price"> $${productosCanciones.precio} </h3>
             <button onclick= "guardarEnCarrito (${productosCanciones.id})" class="buy"> Añadir al carrito </button>
       
             </div>
        </div>`
    }
        
    )
}
displayCards();

function guardarEnCarrito (productoId) {


let item = tracks.find ((producto) => producto.id === productoId)
carrito.push(item)     
console.log(carrito);
renderCarrito()
calcularTotal()
actualizarProductosStorage()
                                          
}
//El carrito de compras//
const contenedorCarrito = document.querySelector ('#contenedor')

const renderCarrito = () => {
contenedorCarrito.innerHTML = ''
carrito.forEach ((item) => {
let div = document.createElement('div')
div.innerHTML = `

<div id='card2' >
<div id='imgbox2'>
<img src=${item.img} alt="" >
</div>

</div>

<p>${item.nombreartista} </p>
<p>Precio: ${item.precio} </p>  
<button onclick= "eliminarItem (${item.id})" class="buy"> Eliminar del carrito </button>
`
contenedorCarrito.append(div)


    } 
)
}

//para el boton eliminar del carrito linkeado en el button//
const eliminarItem = (id) => {

    let borrar = carrito.find((producto) => producto.id === id)
    let indice = carrito.indexOf (borrar)
    carrito.splice (indice,1)
    renderCarrito()
    calcularTotal()
    actualizarProductosStorage()

}
//calcular total y mostrar //
const divPrecio = document.querySelector('#precioTotal')
calcularTotal= () => {

let contador = 0 
carrito.forEach((pre) => {

    contador += pre.precio
})
divPrecio.innerHTML = contador
}

//LOCAL STORAGE Y JSON//


function actualizarProductosStorage (){
let productosJson = JSON.stringify (tracks)  
localStorage.setItem("productos", productosJson)

}






